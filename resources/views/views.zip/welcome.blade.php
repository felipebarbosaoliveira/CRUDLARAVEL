@extends('layout')

@section('content')
    <h1>TESTE</h1>
@endsection